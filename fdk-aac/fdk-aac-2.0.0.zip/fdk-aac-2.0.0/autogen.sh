#!/bin/sh
autoreconf -fiv
